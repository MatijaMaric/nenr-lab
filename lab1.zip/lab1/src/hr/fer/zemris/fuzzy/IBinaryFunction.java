package hr.fer.zemris.fuzzy;

public interface IBinaryFunction {
    double valueAt(double first, double second);
}
