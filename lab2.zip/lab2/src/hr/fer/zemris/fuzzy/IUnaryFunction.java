package hr.fer.zemris.fuzzy;

public interface IUnaryFunction {
    double valueAt(double x);
}
